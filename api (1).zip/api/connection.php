<?php
	error_reporting(0);
$servername = "localhost";
$username = "ankusame_root";
$password = "Ismail@203";
$dbname = "ankusame_purchase_order";

$connectNow = new mysqli($serverHost, $username, $password, $dbname);

  ?>